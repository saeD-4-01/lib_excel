from setuptools import setup

setup(
    name="lib_excel",
    packages=["lib_excel"],
    description="This is a library specifically created for the SAE4.01.",
    version="0.1",
    url="",
    author="Héloïse Rigaux",
    author_email="heloise.rigaux@etu.umontpellier.fr",
    keywords=['pip']
)